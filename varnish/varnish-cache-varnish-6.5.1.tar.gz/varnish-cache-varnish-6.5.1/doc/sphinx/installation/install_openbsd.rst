.. _install-openbsd:

Installing on OpenBSD
=====================

From package
------------

Varnish is distributed in the OpenBSD ports collection as 'www/varnish'::

	pkg_add varnish

From ports
----------

::

	cd /usr/ports/www/varnish
	make install

