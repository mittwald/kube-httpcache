
.. include::	../include/vmod_cookie.generated.rst
