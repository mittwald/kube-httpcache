
.. include::	../include/vmod_std.generated.rst
