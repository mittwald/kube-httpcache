.. _varnish-counters(7):

================
varnish-counters
================

---------------------------------
Varnish counter field definitions
---------------------------------

:Manual section: 7


.. include:: ../include/counters.rst


AUTHORS
=======

This man page was written by Lasse Karstensen, using content from vsc2rst
written by Tollef Fog Heen.
