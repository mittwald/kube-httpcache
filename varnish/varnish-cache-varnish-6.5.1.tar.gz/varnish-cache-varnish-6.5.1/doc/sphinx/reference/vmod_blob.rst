
.. include::	../include/vmod_blob.generated.rst
