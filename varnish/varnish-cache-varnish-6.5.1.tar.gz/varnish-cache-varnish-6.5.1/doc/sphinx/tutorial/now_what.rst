

=========
Now what?
=========

You've read through the tutorial. You should have Varnish up and
running. You should know about the logs and you should have a rough
idea of what VCL is. Next, you might want to have a look at
:ref:`users-guide-index`, where we go through the features of
Varnish in more detail.
