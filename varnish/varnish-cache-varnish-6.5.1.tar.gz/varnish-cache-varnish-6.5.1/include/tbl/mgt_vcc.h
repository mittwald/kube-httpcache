MGT_VCC(unsigned, acl_pedantic,   Acl_Pedantic)
MGT_VCC(unsigned, allow_inline_c, Allow_InlineC)
MGT_VCC(unsigned, err_unref,      Err_Unref)
MGT_VCC(unsigned, unsafe_path,    Unsafe_Path)
#undef MGT_VCC
