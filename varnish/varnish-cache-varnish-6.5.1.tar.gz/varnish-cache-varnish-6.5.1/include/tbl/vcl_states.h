/*lint -save -e525 -e539 */
VCL_STATE(COLD, "cold")
VCL_STATE(WARM, "warm")
VCL_STATE(AUTO, "auto")
#undef VCL_STATE
// LABEL is private to mgt_vcl.c

/*lint -restore */
