#!/bin/sh
#
# Use autogen.des when doing code development

autoreconf -i
